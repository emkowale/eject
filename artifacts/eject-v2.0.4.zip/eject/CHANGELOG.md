v2.0.2 — 2025-12-09

Changed files:
- artifacts/eject-v2.0.1.zip
- eject.php
- package/eject/CHANGELOG.md
- package/eject/README.md
- package/eject/assets/css/admin.css
- package/eject/assets/js/admin.js
- package/eject/eject.php
- package/eject/includes/ajax/class-eject-ajax-run.php
- package/eject/includes/ajax/class-eject-ajax-scan.php
- package/eject/includes/ajax/class-eject-ajax-settings.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-add.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-lines.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-status.php
- package/eject/includes/class-eject-admin.php
- package/eject/includes/class-eject-ajax.php
- package/eject/includes/class-eject-cpt.php
- package/eject/includes/class-eject-service.php
- package/eject/includes/class-eject-workorders.php
- package/eject/includes/data/class-eject-data.php
- package/eject/includes/eject-hooks.php
- package/eject/includes/fonts/dejavusans.ctg.z
- package/eject/includes/fonts/dejavusans.php
- package/eject/includes/fonts/dejavusans.z
- package/eject/includes/fonts/helvetica.php
- package/eject/includes/fonts/helvetica.z
- package/eject/includes/lib/config/tcpdf_config.php
- package/eject/includes/lib/fpdf.php
- package/eject/includes/lib/include/barcodes/qrcode.php
- package/eject/includes/lib/include/tcpdf_colors.php
- package/eject/includes/lib/include/tcpdf_filters.php
- package/eject/includes/lib/include/tcpdf_font_data.php
- package/eject/includes/lib/include/tcpdf_fonts.php
- package/eject/includes/lib/include/tcpdf_images.php
- package/eject/includes/lib/include/tcpdf_static.php
- package/eject/includes/lib/phpqrcode.php
- package/eject/includes/lib/tcpdf.php
- package/eject/includes/lib/tcpdf_autoconfig.php
- package/eject/includes/lib/tcpdf_barcodes_2d.php
- package/eject/includes/views/view-pos.php
- package/eject/includes/views/view-queue.php
- package/eject/includes/views/view-runs.php
- package/eject/includes/views/view-settings.php
- package/eject/release.shv2.0.1 — 2025-12-09

Changed files:
- .gh_release_body.md
- README.md
- artifacts/eject-v1.0.4.zip
- assets/css/admin.css
- assets/js/admin.js
- eject.php
- includes/ajax/class-eject-ajax-run.php
- includes/ajax/class-eject-ajax-scan.php
- includes/ajax/class-eject-ajax-settings.php
- includes/ajax/traits/trait-eject-ajax-run-add.php
- includes/ajax/traits/trait-eject-ajax-run-lines.php
- includes/ajax/traits/trait-eject-ajax-run-status.php
- includes/class-eject-admin.php
- includes/class-eject-ajax.php
- includes/class-eject-cpt.php
- includes/class-eject-service.php
- includes/class-eject-workorders.php
- includes/data/class-eject-data.php
- includes/eject-hooks.php
- includes/fonts/dejavusans.ctg.z
- includes/fonts/dejavusans.php
- includes/fonts/dejavusans.z
- includes/fonts/helvetica.php
- includes/fonts/helvetica.z
- includes/lib/config/tcpdf_config.php
- includes/lib/fpdf.php
- includes/lib/include/barcodes/qrcode.php
- includes/lib/include/tcpdf_colors.php
- includes/lib/include/tcpdf_filters.php
- includes/lib/include/tcpdf_font_data.php
- includes/lib/include/tcpdf_fonts.php
- includes/lib/include/tcpdf_images.php
- includes/lib/include/tcpdf_static.php
- includes/lib/phpqrcode.php
- includes/lib/tcpdf.php
- includes/lib/tcpdf_autoconfig.php
- includes/lib/tcpdf_barcodes_2d.php
- includes/views/view-pos.php
- includes/views/view-queue.php
- includes/views/view-runs.php
- includes/views/view-settings.php
- package/eject/CHANGELOG.md
- package/eject/README.md
- package/eject/assets/css/admin.css
- package/eject/assets/js/admin.js
- package/eject/eject.php
- package/eject/includes/ajax/class-eject-ajax-run.php
- package/eject/includes/ajax/class-eject-ajax-scan.php
- package/eject/includes/ajax/class-eject-ajax-settings.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-add.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-lines.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-status.php
- package/eject/includes/class-eject-admin.php
- package/eject/includes/class-eject-ajax.php
- package/eject/includes/class-eject-cpt.php
- package/eject/includes/data/class-eject-data.php
- package/eject/includes/eject-hooks.php
- package/eject/includes/views/view-pos.php
- package/eject/includes/views/view-queue.php
- package/eject/includes/views/view-runs.php
- package/eject/includes/views/view-settings.php
- package/eject/release.sh
- release.shv1.0.5 — 2025-11-05

Changed files:
- .gh_release_body.md
- artifacts/eject-v1.0.4.zip
- eject.php
- package/eject/CHANGELOG.md
- package/eject/eject.php
- release.shv1.0.4 — 2025-11-05

Changed files:
- README.md
- artifacts/eject-v1.0.3.zip
- assets/css/admin.css
- assets/js/admin.js
- eject.php
- includes/ajax/class-eject-ajax-run.php
- includes/ajax/class-eject-ajax-scan.php
- includes/ajax/class-eject-ajax-settings.php
- includes/ajax/traits/trait-eject-ajax-run-add.php
- includes/ajax/traits/trait-eject-ajax-run-lines.php
- includes/ajax/traits/trait-eject-ajax-run-status.php
- includes/class-eject-admin.php
- includes/class-eject-ajax.php
- includes/class-eject-cpt.php
- includes/data/class-eject-data.php
- includes/eject-hooks.php
- includes/views/view-pos.php
- includes/views/view-queue.php
- includes/views/view-runs.php
- includes/views/view-settings.php
- package/eject/CHANGELOG.md
- package/eject/README.md
- package/eject/assets/css/admin.css
- package/eject/assets/js/admin.js
- package/eject/eject.php
- package/eject/includes/ajax/class-eject-ajax-run.php
- package/eject/includes/ajax/class-eject-ajax-scan.php
- package/eject/includes/ajax/class-eject-ajax-settings.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-add.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-lines.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-status.php
- package/eject/includes/class-eject-admin.php
- package/eject/includes/class-eject-ajax.php
- package/eject/includes/class-eject-cpt.php
- package/eject/includes/data/class-eject-data.php
- package/eject/includes/eject-hooks.php
- package/eject/includes/views/view-pos.php
- package/eject/includes/views/view-queue.php
- package/eject/includes/views/view-runs.php
- package/eject/includes/views/view-settings.php
- package/eject/release.shv1.0.3 — 2025-11-05

Changed files:
- artifacts/eject-v1.0.2.zip
- eject.php
- package/eject/CHANGELOG.md
- package/eject/eject.php
- release.shv1.0.2 — 2025-11-05

Changed files:
- artifacts/eject-v1.0.1.zip
- eject.php
- package/eject/CHANGELOG.md
- package/eject/README.md
- package/eject/assets/css/admin.css
- package/eject/assets/js/admin.js
- package/eject/eject.php
- package/eject/includes/ajax/class-eject-ajax-run.php
- package/eject/includes/ajax/class-eject-ajax-scan.php
- package/eject/includes/ajax/class-eject-ajax-settings.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-add.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-lines.php
- package/eject/includes/ajax/traits/trait-eject-ajax-run-status.php
- package/eject/includes/class-eject-admin.php
- package/eject/includes/class-eject-ajax.php
- package/eject/includes/class-eject-cpt.php
- package/eject/includes/data/class-eject-data.php
- package/eject/includes/eject-hooks.php
- package/eject/includes/views/view-pos.php
- package/eject/includes/views/view-queue.php
- package/eject/includes/views/view-runs.php
- package/eject/includes/views/view-settings.php
- package/eject/release.sh

v1.0.1 — 2025-11-05

Changed files:
- README.md
- assets/css/admin.css
- assets/js/admin.js
- eject.php
- includes/ajax/class-eject-ajax-run.php
- includes/ajax/class-eject-ajax-scan.php
- includes/ajax/class-eject-ajax-settings.php
- includes/ajax/traits/trait-eject-ajax-run-add.php
- includes/ajax/traits/trait-eject-ajax-run-lines.php
- includes/ajax/traits/trait-eject-ajax-run-status.php
- includes/class-eject-admin.php
- includes/class-eject-ajax.php
- includes/class-eject-cpt.php
- includes/data/class-eject-data.php
- includes/eject-hooks.php
- includes/views/view-pos.php
- includes/views/view-queue.php
- includes/views/view-runs.php
- includes/views/view-settings.php
- release.sh

# 🧾 Eject Changelog

All notable changes to **Eject** will be documented in this file.  
This project follows [Semantic Versioning](https://semver.org/).

---

## [1.0.0] - 2025-11-03
### Added
- Initial plugin scaffold for Eject
- Custom Post Type `eject_run` for purchase orders and runs
- Admin screens: Queue, Runs, POs, Settings
- WooCommerce integration for Processing orders
- AJAX endpoints and Woo spinner interactions
- GitHub-compatible metadata for WordPress update functionality
- README.md and CHANGELOG.md added for release.sh automation

---

## [Unreleased]

## [2.0.4] - 2025-12-09

### Changes
* chore(release): v2.0.3 (4373388)


## [2.0.3] - 2025-12-09

### Changes
* chore(release): v2.0.2 (changelog) (f838bbb)
* chore(release): v2.0.2 (bump) (4f547d6)

### Planned
- Vendor email integration for automatic PO dispatch
- Integration with **Tracks** for work order generation
- Extended reporting and vendor cost tracking
